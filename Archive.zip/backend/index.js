// Impor library yang sudah diinstal
const pool = require('./db');
const express = require('express');
const cors = require('cors');

// Inisialisasi aplikasi express
const app = express();
const port = 5001; // Kita akan jalankan server di port 5000

// Middleware (agar frontend bisa akses dan kita bisa baca JSON)
app.use(cors());
app.use(express.json());

// "Endpoint" atau "Rute" pertama kita
app.get('/', (req, res) => {
  res.send('Halo, ini adalah server K3 Anda!');
});

// RUTE BARU UNTUK TES KONEKSI DATABASE
app.get('/testdb', async (req, res) => {
  try {
    const result = await pool.query('SELECT NOW()'); // Kueri sederhana
    res.json({
      message: 'Koneksi database BERHASIL!',
      time: result.rows[0].now,
    });
  } catch (err) {
    console.error('Error saat tes koneksi database', err.stack);
    res.status(500).json({
      message: 'Koneksi database GAGAL!',
      error: err.message,
    });
  }
});

// RUTE BARU: MEMBUAT LAPORAN INSIDEN BARU (POST)
app.post('/api/laporan', async (req, res) => {
  try {
    // 1. Ambil data yang dikirim dari luar (Postman/Frontend)
    const { tanggal_kejadian, lokasi, jenis_insiden, deskripsi, status_laporan } = req.body;

    // 2. Buat kueri SQL untuk MENYISIPKAN data
    const kueri = `
      INSERT INTO laporan_insiden 
        (tanggal_kejadian, lokasi, jenis_insiden, deskripsi, status_laporan) 
      VALUES 
        ($1, $2, $3, $4, $5) 
      RETURNING *
    `; 
    // RETURNING * akan mengembalikan data yang baru saja dibuat

    // 3. Kirim kueri ke database
    const laporanBaru = await pool.query(kueri, [
      tanggal_kejadian,
      lokasi,
      jenis_insiden,
      deskripsi,
      status_laporan
    ]);

    // 4. Kirim balasan sukses
    res.status(201).json({
      message: 'Laporan berhasil dibuat!',
      data: laporanBaru.rows[0] // Tampilkan data yang baru dibuat
    });

  } catch (err) {
    console.error('Error saat membuat laporan:', err.stack);
    res.status(500).json({
      message: 'Gagal membuat laporan!',
      error: err.message
    });
  }
});

// RUTE BARU: MENDAPATKAN SEMUA LAPORAN INSIDEN (GET)
app.get('/api/laporan', async (req, res) => {
  try {
    const kueri = 'SELECT * FROM laporan_insiden ORDER BY tanggal_kejadian DESC';
    const semuaLaporan = await pool.query(kueri);

    res.status(200).json({
      message: 'Data semua laporan berhasil diambil!',
      count: semuaLaporan.rowCount, // Jumlah data
      data: semuaLaporan.rows // Data laporannya
    });

  } catch (err) {
    console.error('Error saat mengambil laporan:', err.stack);
    res.status(500).json({
      message: 'Gagal mengambil data!',
      error: err.message
    });
  }
});

// Menjalankan server
app.listen(port, () => {
  console.log(`Server backend berjalan di http://localhost:${port}`);
});