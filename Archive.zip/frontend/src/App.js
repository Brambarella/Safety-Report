import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './App.css';

function App() {
  const [laporan, setLaporan] = useState([]);
  const [loading, setLoading] = useState(true);

  // --- State untuk Formulir ---
  const [lokasi, setLokasi] = useState('');
  const [jenis, setJenis] = useState('Near Miss'); // Default value
  const [deskripsi, setDeskripsi] = useState('');

  // --- Fungsi untuk mengambil data (GET) ---
  const ambilData = async () => {
    try {
      setLoading(true);
      const hasil = await axios.get('http://localhost:5001/api/laporan');
      setLaporan(hasil.data.data);
      setLoading(false);
    } catch (err) {
      console.error("Gagal mengambil data:", err);
      setLoading(false);
    }
  };

  // --- useEffect untuk mengambil data saat dimuat ---
  useEffect(() => {
    ambilData(); // Panggil fungsinya
  }, []);

  // --- Fungsi untuk MENGIRIM data baru (POST) ---
  const handleSubmit = async (e) => {
    e.preventDefault(); // Mencegah refresh halaman
    
    // Validasi sederhana
    if (!lokasi || !deskripsi) {
      alert('Lokasi dan Deskripsi wajib diisi!');
      return;
    }

    try {
      const dataBaru = {
        tanggal_kejadian: new Date().toISOString(), // Waktu saat ini
        lokasi: lokasi,
        jenis_insiden: jenis,
        deskripsi: deskripsi,
        status_laporan: 'Baru Dilaporkan'
      };

      // Kirim data ke backend!
      await axios.post('http://localhost:5001/api/laporan', dataBaru);
      
      // Jika berhasil:
      alert('Laporan berhasil dikirim!');
      
      // Kosongkan formulir
      setLokasi('');
      setJenis('Near Miss');
      setDeskripsi('');
      
      // Ambil ulang data terbaru dari server
      ambilData(); 

    } catch (err) {
      console.error('Gagal mengirim laporan:', err);
      alert('Gagal mengirim laporan. Cek console.');
    }
  };

  // --- Tampilan (Render) ---
  return (
    <div className="App">
      <header className="App-header">
        <h1>Rekap Laporan Insiden K3</h1>
        
        {/* --- FORMULIR INPUT --- */}
        <form onSubmit={handleSubmit} style={{ width: '80%', fontSize: '16px', border: '2px solid white', padding: '20px', borderRadius: '10px' }}>
          <h3>Buat Laporan Baru</h3>
          
          <div style={{ margin: '10px 0', textAlign: 'left' }}>
            <label>Lokasi:</label><br />
            <input 
              type="text" 
              value={lokasi}
              onChange={(e) => setLokasi(e.target.value)}
              style={{ width: '100%', padding: '5px' }}
            />
          </div>

          <div style={{ margin: '10px 0', textAlign: 'left' }}>
            <label>Jenis Insiden:</label><br />
            <select 
              value={jenis} 
              onChange={(e) => setJenis(e.target.value)}
              style={{ width: '100%', padding: '5px' }}
            >
              <option value="Near Miss">Near Miss</option>
              <option value="First Aid">First Aid (P3K)</option>
              <option value="LTI">LTI (Lost Time Injury)</option>
              <option value="Property Damage">Property Damage</option>
            </select>
          </div>

          <div style={{ margin: '10px 0', textAlign: 'left' }}>
            <label>Deskripsi:</label><br />
            <textarea 
              value={deskripsi}
              onChange={(e) => setDeskripsi(e.target.value)}
              style={{ width: '100%', padding: '5px', height: '80px' }}
            />
          </div>
          
          <button type="submit" style={{ padding: '10px 20px', fontSize: '16px', cursor: 'pointer' }}>
            Kirim Laporan
          </button>
        </form>

        <hr style={{width: '80%', margin: '30px 0'}} />

        {/* --- DAFTAR LAPORAN --- */}
        <h2>Daftar Laporan Masuk</h2>
        {loading && <p>Loading data...</p>}
        
        <div style={{ textAlign: 'left', fontSize: '16px', width: '80%' }}>
          {laporan.map((item) => (
            <div key={item.id} style={{ border: '1px solid gray', padding: '10px', margin: '10px', borderRadius: '5px' }}>
              <p><strong>Lokasi:</strong> {item.lokasi}</p>
              <p><strong>Jenis:</strong> {item.jenis_insiden}</p>
              <p><strong>Deskripsi:</strong> {item.deskripsi}</p>
              <p><strong>Status:</strong> {item.status_laporan}</p>
              <p><em>Dilaporkan pada: {new Date(item.created_at).toLocaleString()}</em></p>
            </div>
          ))}
        </div>
      </header>
    </div>
  );
}

export default App;